//
//  CreatePlayerView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/29/24.
//

import SwiftUI

struct CreatePlayerView: View {
    @ObservedObject var playerViewModel = PlayerViewModel()
    @State private var playerName: String = ""
    @State private var playerGamertag: String = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack {
            Text("Create Player")
                .font(.largeTitle)
                .padding()

            TextField("Player Name", text: $playerName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            TextField("Player Gamertag", text: $playerGamertag)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button(action: {
                if isGamertagUnique(gamertag: playerGamertag) {
                    let newPlayer = Player(name: playerName, gamertag: playerGamertag)
                    playerViewModel.addPlayer(player: newPlayer) { success in
                        if success {
                            alertMessage = "Player added successfully!"
                            showAlert = true
                        } else {
                            alertMessage = "Failed to add player. Try again."
                            showAlert = true
                        }
                    }
                } else {
                    alertMessage = "Gamertag already taken. Please choose a different one."
                    showAlert = true
                }
            }) {
                Text("Save Player")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
            }
            .padding(.bottom, 20)
            .alert(isPresented: $showAlert) {
                Alert(title: Text(""), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }

            Button(action: {
                playerViewModel.deletePlayer(gamertag: playerGamertag) { success in
                    if success {
                        alertMessage = "Player removed successfully!"
                        showAlert = true
                    } else {
                        alertMessage = "Failed to remove player. Try again."
                        showAlert = true
                    }
                }
            }) {
                Text("Remove Player")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
            }
            .padding(.bottom, 20)
        }
        .onAppear {
            playerViewModel.fetchPlayers()
        }
    }

    private func isGamertagUnique(gamertag: String) -> Bool {
        !playerViewModel.players.contains { $0.gamertag.lowercased() == gamertag.lowercased() }
    }
}

struct CreatePlayerView_Previews: PreviewProvider {
    static var previews: some View {
        CreatePlayerView()
    }
}




