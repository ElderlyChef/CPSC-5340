//
//  HomeNavigationView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/29/24.
//

import SwiftUI

struct HomeNavigationView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("Halo LAN Manager")
                    .font(.largeTitle)
                    .padding(.top, 50)

                Spacer()

                VStack(spacing: 20) {
                    NavigationLink(destination: CreatePlayerView()) {
                        Text("Create Player")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 0.77, green: 0.12, blue: 0.23))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }

                    NavigationLink(destination: CreateLanResultsView()) {
                        Text("Create LAN Results")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 0.0, green: 0.5, blue: 1.0))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }

                    NavigationLink(destination: PastResultsView()) {
                        Text("View Past Results")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 0.77, green: 0.12, blue: 0.23))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }

                    NavigationLink(destination: LeaderboardView()) {
                        Text("View Leaderboard")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 0.0, green: 0.5, blue: 1.0))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 50)

                Spacer()
            }
        }
        .accentColor(Color(red: 0.0, green: 0.5, blue: 1.0))
    }
}

struct HomeNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        HomeNavigationView()
            .preferredColorScheme(.dark)
    }
}


