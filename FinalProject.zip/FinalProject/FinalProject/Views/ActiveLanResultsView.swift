//
//  ActiveLanResultsView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 7/1/24.
//

import SwiftUI

struct ActiveLANResultsView: View {
    @ObservedObject var lanResultsViewModel = LANResultsViewModel()
    @State private var lanResults: LANResults
    @Environment(\.presentationMode) var presentationMode
    @State private var showAddPlayerView = false

    init(lanResults: LANResults) {
        _lanResults = State(initialValue: lanResults)
    }

    var body: some View {
        VStack {
            Text(lanResults.name)
                .font(.largeTitle)
                .padding(.top, 20)

            List(lanResults.players.keys.sorted(), id: \.self) { gamertag in
                if let stats = lanResults.players[gamertag] {
                    VStack {
                        HStack {
                            Text(gamertag)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            VStack {
                                HStack {
                                    Text("W: ")
                                    TextField("Wins", value: Binding(
                                        get: { stats.wins },
                                        set: { newValue in
                                            updatePlayerStats(gamertag: gamertag, wins: newValue, losses: stats.losses)
                                        }
                                    ), formatter: NumberFormatter())
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(width: 40)
                                    Stepper("", value: Binding(
                                        get: { stats.wins },
                                        set: { newValue in
                                            updatePlayerStats(gamertag: gamertag, wins: newValue, losses: stats.losses)
                                        }
                                    ), in: 0...1000)
                                }
                                HStack {
                                    Text("L: ")
                                    TextField("Losses", value: Binding(
                                        get: { stats.losses },
                                        set: { newValue in
                                            updatePlayerStats(gamertag: gamertag, wins: stats.wins, losses: newValue)
                                        }
                                    ), formatter: NumberFormatter())
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .frame(width: 40)
                                    Stepper("", value: Binding(
                                        get: { stats.losses },
                                        set: { newValue in
                                            updatePlayerStats(gamertag: gamertag, wins: stats.wins, losses: newValue)
                                        }
                                    ), in: 0...1000)
                                }
                            }
                        }
                    }
                    .padding(.vertical, 10)
                }
            }

            Button(action: {
                print("Save LAN Results button pressed")
                saveLANResults()
            }) {
                Text("Save LAN Results")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
            }
            .padding(.bottom, 10)

            HStack {
                Button(action: {
                    print("Add Player button pressed")
                    showAddPlayerView = true
                }) {
                    Text("Add Player")
                        .font(.title2)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal, 10)
                }

                Button(action: {
                    print("Delete LAN Results button pressed")
                    presentDeleteConfirmation()
                }) {
                    Text("Delete LAN Results")
                        .font(.title2)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal, 10)
                }
            }
            .padding(.bottom, 20)
        }
        .sheet(isPresented: $showAddPlayerView) {
            AddPlayerView(selectedPlayers: $lanResults.players, showAddPlayerView: $showAddPlayerView)
        }
        .onAppear {
            lanResultsViewModel.fetchLANResults()
        }
    }

    private func updatePlayerStats(gamertag: String, wins: Int, losses: Int) {
        if var stats = lanResults.players[gamertag] {
            stats.wins = wins
            stats.losses = losses
            lanResults.players[gamertag] = stats
            print("Updating stats for \(gamertag) - Wins: \(wins), Losses: \(losses)")
            lanResultsViewModel.updatePlayerStats(lanResultsId: lanResults.id ?? "", gamertag: gamertag, wins: wins, losses: losses)
        }
    }

    private func saveLANResults() {
        print("Saving LAN results")
        lanResultsViewModel.updateLANResults(lanResults: lanResults)
    }

    private func presentDeleteConfirmation() {
        let alert = UIAlertController(title: "Delete LAN Results", message: "Are you sure you would like to delete \(lanResults.name)?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            if let id = self.lanResults.id {
                self.lanResultsViewModel.deleteLANResults(lanResultsId: id)
                self.presentationMode.wrappedValue.dismiss()
            }
        }))
        UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true, completion: nil)
    }
}

struct ActiveLANResultsView_Previews: PreviewProvider {
    static var previews: some View {
        let samplePlayers = [
            Player(name: "Sample Player 1", gamertag: "SampleGT1"),
            Player(name: "Sample Player 2", gamertag: "SampleGT2")
        ]
        let sampleLANResults = LANResults(name: "Sample LAN", date: Date(), players: samplePlayers)
        ActiveLANResultsView(lanResults: sampleLANResults)
    }
}










