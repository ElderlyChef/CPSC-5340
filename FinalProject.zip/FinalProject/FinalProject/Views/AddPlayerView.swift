//
//  AddPlayerView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/29/24.
//

import SwiftUI

struct AddPlayerView: View {
    @ObservedObject var playerViewModel = PlayerViewModel()
    @Binding var selectedPlayers: [String: LANResults.PlayerStats]
    @Binding var showAddPlayerView: Bool

    var body: some View {
        VStack {
            Text("Add Player to LAN Results")
                .font(.largeTitle)
                .padding()

            List {
                ForEach(playerViewModel.players.filter { selectedPlayers[$0.gamertag] == nil }) { player in
                    HStack {
                        Text(player.gamertag)
                        Spacer()
                        Button(action: {
                            selectedPlayers[player.gamertag] = LANResults.PlayerStats(wins: 0, losses: 0)
                            showAddPlayerView = false
                        }) {
                            Text("Add")
                                .foregroundColor(.blue)
                        }
                    }
                }
            }

            Button(action: {
                showAddPlayerView = false
            }) {
                Text("Cancel")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
            }
            .padding(.bottom, 20)
        }
        .onAppear {
            playerViewModel.fetchPlayers()
        }
    }
}

struct AddPlayerView_Previews: PreviewProvider {
    @State static var selectedPlayers = [String: LANResults.PlayerStats]()
    @State static var showAddPlayerView = true

    static var previews: some View {
        AddPlayerView(selectedPlayers: $selectedPlayers, showAddPlayerView: $showAddPlayerView)
    }
}


