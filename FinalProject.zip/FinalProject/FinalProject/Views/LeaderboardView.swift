//
//  LeaderboardView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/28/24.
//

import SwiftUI

struct LeaderboardView: View {
    @ObservedObject var lanResultsViewModel = LANResultsViewModel()

    var body: some View {
        VStack {
            Text("Leaderboard")
                .font(.largeTitle)
                .padding(.top, 20)

            List {
                ForEach(getLeaderboard(), id: \.0) { player, stats in
                    HStack {
                        Text(player)
                        Spacer()
                        Text("W: \(stats.wins) L: \(stats.losses)")
                    }
                }
            }

            Spacer()
        }
        .onAppear {
            lanResultsViewModel.fetchLANResults()
        }
    }

    private func getLeaderboard() -> [(String, LANResults.PlayerStats)] {
        var leaderboard: [String: LANResults.PlayerStats] = [:]

        for lanResult in lanResultsViewModel.lanResults {
            for (player, stats) in lanResult.players {
                if let existingStats = leaderboard[player] {
                    leaderboard[player] = LANResults.PlayerStats(
                        wins: existingStats.wins + stats.wins,
                        losses: existingStats.losses + stats.losses
                    )
                } else {
                    leaderboard[player] = stats
                }
            }
        }

        return leaderboard.sorted { $0.value.wins > $1.value.wins }
    }
}

struct LeaderboardView_Previews: PreviewProvider {
    static var previews: some View {
        LeaderboardView()
    }
}



