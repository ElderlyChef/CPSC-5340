//
//  PastResultsView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 7/1/24.
//

import SwiftUI

struct PastResultsView: View {
    @ObservedObject var lanResultsViewModel = LANResultsViewModel()
    @State private var selectedLANResults: LANResults?
    @State private var navigateToActiveLANResults = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Past Results")
                .font(.largeTitle)
                .padding(.top, 20)

            if lanResultsViewModel.lanResults.isEmpty {
                Text("No LAN Results Available")
                    .font(.title2)
                    .padding(.top, 20)
            } else {
                Picker("Select LAN Results", selection: $selectedLANResults) {
                    ForEach(lanResultsViewModel.lanResults, id: \.self) { lanResult in
                        Text(lanResult.name).tag(lanResult as LANResults?)
                    }
                }
                .pickerStyle(MenuPickerStyle())

                if let selectedLANResults = selectedLANResults {
                    Text("Selected: \(selectedLANResults.name)")

                    Button(action: {
                        navigateToActiveLANResults = true
                    }) {
                        Text("Make LAN Active")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding(.horizontal, 20)
                    }
                }
            }

            Spacer()
        }
        .padding(.horizontal, 20)
        .background(
            NavigationLink(
                destination: selectedLANResults.map { ActiveLANResultsView(lanResults: $0) },
                isActive: $navigateToActiveLANResults
            ) {
                EmptyView()
            }
        )
        .onAppear {
            lanResultsViewModel.fetchLANResults()
        }
    }
}

struct PastResultsView_Previews: PreviewProvider {
    static var previews: some View {
        PastResultsView()
    }
}




