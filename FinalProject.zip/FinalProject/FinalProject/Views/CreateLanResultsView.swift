//
//  CreateLanResultsView.swift
//  FinalProject
//
//  Created by Jonathan Elder on 7/1/24.
//

import SwiftUI

struct CreateLanResultsView: View {
    @ObservedObject var playerViewModel = PlayerViewModel()
    @ObservedObject var lanResultsViewModel = LANResultsViewModel()
    @State private var lanName: String = ""
    @State private var selectedDate = Date()
    @State private var selectedPlayers: Set<String> = []
    @State private var navigateToActiveLANResults = false
    @State private var createdLANResults: LANResults?

    var body: some View {
        VStack(spacing: 20) {
            TextField("LAN Name", text: $lanName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal, 20)

            DatePicker("Date", selection: $selectedDate, displayedComponents: .date)
                .padding(.horizontal, 20)

            List(playerViewModel.players) { player in
                HStack {
                    Text(player.name)
                    Spacer()
                    Text(player.gamertag)
                    Spacer()
                    Image(systemName: selectedPlayers.contains(player.gamertag) ? "checkmark.circle.fill" : "circle")
                        .onTapGesture {
                            if selectedPlayers.contains(player.gamertag) {
                                selectedPlayers.remove(player.gamertag)
                            } else {
                                selectedPlayers.insert(player.gamertag)
                            }
                        }
                }
            }

            Button(action: {
                let selectedPlayerObjects = playerViewModel.players.filter { selectedPlayers.contains($0.gamertag) }
                let newLANResults = LANResults(name: lanName, date: selectedDate, players: selectedPlayerObjects)
                lanResultsViewModel.addLANResults(lanResults: newLANResults) { lanResults in
                    if let lanResults = lanResults {
                        createdLANResults = lanResults
                        navigateToActiveLANResults = true
                    }
                }
                lanName = ""
                selectedPlayers = []
            }) {
                Text("Create LAN Results")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
            }
            Spacer()
        }
        .padding(.top, 40)
        .onAppear {
            playerViewModel.fetchPlayers()
        }
        .background(
            NavigationLink(
                destination: createdLANResults.map { ActiveLANResultsView(lanResults: $0) },
                isActive: $navigateToActiveLANResults
            ) {
                EmptyView()
            }
        )
    }
}

struct CreateLANResultsView_Previews: PreviewProvider {
    static var previews: some View {
        CreateLanResultsView()
    }
}




