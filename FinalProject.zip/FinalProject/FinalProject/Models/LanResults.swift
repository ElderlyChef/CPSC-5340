//
//  LanResults.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/20/24.
//

import Foundation
import FirebaseFirestoreSwift

struct LANResults: Identifiable, Codable, Hashable {
    @DocumentID var id: String?
    var name: String
    var date: Date
    var players: [String: PlayerStats]

    struct PlayerStats: Codable, Hashable {
        var wins: Int
        var losses: Int
    }

    init(name: String, date: Date, players: [Player]) {
        self.name = name
        self.date = date
        self.players = Dictionary(uniqueKeysWithValues: players.map { ($0.gamertag, PlayerStats(wins: 0, losses: 0)) })
    }
}

