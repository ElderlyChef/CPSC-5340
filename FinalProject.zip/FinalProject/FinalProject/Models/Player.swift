//
//  Player.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/20/24.
//

import Foundation
import FirebaseFirestoreSwift

struct Player: Identifiable, Codable {
    @DocumentID var id: String?
    var name: String
    var gamertag: String
    var wins: Int
    var losses: Int

    init(name: String, gamertag: String) {
        self.name = name
        self.gamertag = gamertag
        self.wins = 0
        self.losses = 0
    }
}

