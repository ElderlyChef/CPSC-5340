//
//  LanResultsViewModel.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/29/24.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class LANResultsViewModel: ObservableObject {
    @Published var lanResults = [LANResults]()
    private var db = Firestore.firestore()

    func fetchLANResults() {
        db.collection("lanResults").addSnapshotListener { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }

            self.lanResults = documents.compactMap { queryDocumentSnapshot -> LANResults? in
                try? queryDocumentSnapshot.data(as: LANResults.self)
            }
        }
    }

    func addLANResults(lanResults: LANResults, completion: @escaping (LANResults?) -> Void) {
        do {
            var newLANResults = lanResults
            let ref = try db.collection("lanResults").addDocument(from: lanResults)
            newLANResults.id = ref.documentID
            try ref.setData(from: newLANResults) { error in
                if let error = error {
                    print("Error setting document ID: \(error)")
                    completion(nil)
                } else {
                    completion(newLANResults)
                }
            }
        } catch {
            print("Error adding LAN results: \(error)")
            completion(nil)
        }
    }

    func updatePlayerStats(lanResultsId: String, gamertag: String, wins: Int, losses: Int) {
        guard !lanResultsId.isEmpty else {
            print("Document path cannot be empty.")
            return
        }

        let docRef = db.collection("lanResults").document(lanResultsId)
        docRef.getDocument { (document, error) in
            guard let document = document, document.exists, var lanResults = try? document.data(as: LANResults.self) else {
                print("Document does not exist or failed to decode")
                return
            }

            if var stats = lanResults.players[gamertag] {
                stats.wins = wins
                stats.losses = losses
                lanResults.players[gamertag] = stats

                do {
                    try docRef.setData(from: lanResults)
                    print("Successfully updated stats for \(gamertag) - Wins: \(wins), Losses: \(losses)")
                } catch {
                    print("Failed to update document: \(error)")
                }
            } else {
                print("Player stats not found")
            }
        }
    }

    func updateLANResults(lanResults: LANResults) {
        guard let lanResultsId = lanResults.id else {
            print("LAN Results ID is missing")
            return
        }

        do {
            try db.collection("lanResults").document(lanResultsId).setData(from: lanResults)
        } catch {
            print("Error updating LAN results: \(error)")
        }
    }

    func deleteLANResults(lanResultsId: String) {
        db.collection("lanResults").document(lanResultsId).delete { error in
            if let error = error {
                print("Error removing document: \(error)")
            } else {
                print("Document successfully removed!")
            }
        }
    }
}








