//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/20/24.
//

import SwiftUI
import Firebase

@main
struct FinalProjectApp: App {
    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            HomeNavigationView()
        }
    }
}
