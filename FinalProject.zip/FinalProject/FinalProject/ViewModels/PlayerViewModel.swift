//
//  PlayerViewModel.swift
//  FinalProject
//
//  Created by Jonathan Elder on 6/29/24.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class PlayerViewModel: ObservableObject {
    @Published var players = [Player]()
    private var db = Firestore.firestore()

    func fetchPlayers() {
        db.collection("players").addSnapshotListener { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }

            self.players = documents.compactMap { queryDocumentSnapshot -> Player? in
                try? queryDocumentSnapshot.data(as: Player.self)
            }
        }
    }

    func addPlayer(player: Player, completion: @escaping (Bool) -> Void) {
        do {
            _ = try db.collection("players").addDocument(from: player) { error in
                if let error = error {
                    print("Error adding player: \(error)")
                    completion(false)
                } else {
                    completion(true)
                }
            }
        } catch {
            print("Error adding player: \(error)")
            completion(false)
        }
    }

    func deletePlayer(gamertag: String, completion: @escaping (Bool) -> Void) {
        db.collection("players").whereField("gamertag", isEqualTo: gamertag).getDocuments { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents, !documents.isEmpty else {
                print("No matching documents")
                completion(false)
                return
            }

            for document in documents {
                self.db.collection("players").document(document.documentID).delete { error in
                    if let error = error {
                        print("Error deleting player: \(error)")
                        completion(false)
                    } else {
                        completion(true)
                    }
                }
            }
        }
    }
}

